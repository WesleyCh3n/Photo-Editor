//=================================================================================
//  PROGRAMMER   : ZHUOLUN NIU 
//  DATE         : 2017-12-05
//  FILENAME     : HW05CT06502105.CPP 
//  DESCRIPTION  : This is a program to  constructs and displays a magic square for 
//                 any given odd number N
//=================================================================================
#include "stdafx.h"
#include <iostream>
#include <iomanip>
//#include <new>
using namespace std;

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main()
{
	/*Define five integers:
	    N to store the odd number input by user;
		i, j to be the pointer;
		m, n to be the script of the element;
		num to be the number put in the square.        */
	int N, i, j, m, n, num;

	//Alert the user to input an odd number and store it in N.
	cout << "Please input an odd:";
	cin >> N;

	//Use dynamic allocation to difine a two-dimension N*N matrix
	int **mag = new int *[N];
	for ( i = 0; i<N; i++)
	{
		mag[i] = new int[N];
	}
	//Initilaze the elements in the matrix to be 0
	for (i = 0; i < N; i++)
	{
		for (j = 0; j < N; j++)
			mag[i][j] = 0;
		
	}

	//Insert the value 1 in the middle of the first row (element [0][N/2]).
	m = 0, n = N / 2;
	mag[m][n] = 1;
	num = 2;
	//Use for loop to insert the numbers in the square by order
	for (num = 2; num <= N*N; num++)
	{
		/*If the element is moved off the top(row = -1) in any column, then change the index to N-1,
		  else, change it to m-1.             */
		if (m - 1 < 0)
			m = N - 1;
		else
			m = m - 1;
		/*If the element is moved off the right end(column = N) of a row, then change the index to 0,
		  else, change it to n+1.                               */
		if (n + 1 > N - 1)
			n = 0;
		else
			n = n + 1;
		/*If the element is moved to a position that is already filled or out of the upper - right corner,
		  then place the next number, x+1, immediately below x.                  */
		if (mag[m][n] == 0)
			mag[m][n] = num;
		else
			for (i = 0; i < N; i++)
			{
				for (j = 0; j < N; j++)
					if (mag[i][j] == num - 1)
					{
						m = i + 1, n = j;
						mag[m][n] = num;
					}
			}
	}
	//Show the magic square on the screen
	for (i = 0; i < N; i++)
	{
		for (j = 0; j < N; j++)
			cout << setw(3) << mag[i][j];
		cout << endl;
	}

	answer1 = mag[0][0];  //Store the integer value of the cell at the top-left corner
	answer2 = mag[N - 1][N - 1];  //Store the integer value of the cell at the bottom - right corner
	//getchar();
	//getchar();
    delete []mag;
    return 0;
}

