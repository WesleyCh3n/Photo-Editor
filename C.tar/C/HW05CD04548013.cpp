//  PROGRAMMER  : D04548013 Wang,Hao-Jen
//  DATE        : 2017-12-07
//  FILENAME    : HW04CD04548013.CPP
//  DESCRIPTION :magic square
//=======================================================

#include<iostream>
#include<iomanip>
#include<vector>
using namespace std;

	int answer1;     // Store the integer value of the cell at the top-left corner
	int answer2;     // Store the integer value of the cell at the bottom-right corner


void magic_S(int X)
{
	vector<vector<int> > Sq_X(X, vector<int>(X));
	for (int i = 0; i < X; i++)
	{
		for (int j = 0; j < X; j++)
		{
			Sq_X[i][j] = 0;
		}
	}
	int i = 0, j = (X - 1) / 2, tempi, tempj;
	for (int t = 1; t <= X*X; t++)
	{
		if (t == 1)
			Sq_X[i][j] = 1;
		else
		{
			tempi = i;
			tempj = j;
			// Find the next location
			if ((i == 0) && (j == X - 1)) // Upper right corner
				i++;
			else if (i == 0) // The top row
			{
				i = X - 1;
				j++;
			}
			else if (j == X - 1) // Rightmost column
			{
				i--;
				j = 0;
			}
			else
			{
				i--;
				j++;
			}
			
			if (Sq_X[i][j] == 0) //Fill in the numbers
				Sq_X[i][j] = t;
			else 
			{
				i = tempi;
				j = tempj;
				i++;
				Sq_X[i][j] = t;
			}
		}
	}
	cout << " The " << X << "x" << X << " magic square is:" << ""<<endl;
	for (int i1 = 0; i1 < X; i1++)
	{
		for (int j1 = 0; j1 < X; j1++)
		{
			cout << setw(4) << Sq_X[i1][j1];
		}
		cout << ""<<endl;
	}
	cout << ""<<endl;
	answer1 = Sq_X[0][0]; // the cell at the top-left corner
	answer2 = Sq_X[X-1][X-1]; //the cell at the bottom-right corner
}


int main() {
	int X;
	cout << "Please enter the size of magic square you want to create."<<endl;
	cin >> X;

	if (X % 2 == 0)
		cout << "The size must be odd number. Please enter again."<<endl;
	else
		magic_S(X);

	return 0;
}

