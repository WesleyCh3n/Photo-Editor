#include<iostream>
using namespace std;

//================================================================
//  PROGRAMMER  : lai, Yin-Hao 
//  DATE        : 2017-12-04
//  FILENAME    : HW05CB06611006.CPP 
//  DESCRIPTION : This is a program that can find twin prime numbers.
//================================================================

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main()
{
	int n, i, j, c=0, d, e, f;
	cout<<"Please input an odd number:";
	cin>>n;
	int a[n][n];
	for(i=0;i<n;i++){            //all the elements of the array should start with "0"
		for(j=0;j<n;j++){
			a[i][j]=0;
		}
	}          
    d=n/2;
	e=c;
	f=d;                                
	for(i=1;i<=n*n;i++){          //the function that can put all the number into the array correctly
		a[c][d]=i;
		e--;
		f++;
		if(e<0)e=n-1;
		if(f==n)f=0;
		if(a[e][f]!=0){
			e=c+1;
			f=d;
			if(e==n)e=0;	
		}
		c=e;
		d=f;
	}
	for(i=0;i<n;i++){     //print out the array
		for(j=0;j<n;j++)
		{
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
	
	system("pause");
	return 0;
}

 
