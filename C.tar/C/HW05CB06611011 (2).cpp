//  PROGRAMMER : LIN YU HUNG
//  DATE       : 2017.12.6
//  DESCRIPTION: Magic square

#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int answer1, answer2;

int main()
{
	int n;
	cin >> n;
	int ps[n][n];
	int r = 0, c = n / 2, t = 1;
	int max = pow(n, 2);

	for (int i = 0; i<n; i++)
	{
		for (int j = 0; j<n; j++)
		{
			ps[i][j] = 0;
		}
	}

	ps[r][c] = t;

	for (t = 2; t <= max; t++)
	{
		if (r>0 && c<n - 1 && ps[r - 1][c + 1] == 0)//move 1 upward and 1 leftward if there is not value
		{
			r--;
			c++;
			ps[r][c] = t;
		}

		else if (r>0 && r<n - 1 && c<n - 1 && ps[r - 1][c + 1] != 0)//move 1 downward when there is a value
		{
			r++;
			ps[r][c] = t;
		}
		else if (r>0 && c == n - 1 && ps[r - 1][0] == 0)//at the left side go to front
		{
			r--;
			c = 0;
			ps[r][c] = t;
		}
		else if (r>0 && r<n - 1 && c == n - 1 && ps[r - 1][0] != 0)
		{
			r++;
			ps[r][c] = t;
		}
		else if (r == 0 && c<n - 1 && ps[n - 1][c + 1] == 0)
		{
			r = n - 1;
			c++;
			ps[r][c] = t;
		}
		else if (r == 0 && c<n - 1 && ps[n - 1][c + 1] != 0)
		{
			r++;
			ps[r][c] = t;
		}
		else if (r == 0 && c == n - 1 && ps[n - 1][0] == 0)
		{
			r = n - 1;
			c = 0;
			ps[r][c] = t;
		}
		else if (r == 0 && c == n - 1 && ps[n - 1][0] != 0)
		{
			r++;
			ps[r][c] = t;
		}
		else if (r == n - 1 && c == n - 1 && ps[r - 1][0] != 0)
		{
			r = 0;
			ps[r][c] = t;
		}
		else if (r == n - 1 && c<n - 1 && ps[r - 1][c + 1] != 0)
		{
			r = 0;
			ps[r][c] = t;
		}
	}

	for (int i = 0; i<n; i++)
	{
		for (int j = 0; j<n; j++)
		{
			cout << setw(2) << ps[i][j] << " ";
		}
		cout << endl;
	}

	answer1 = ps[0][0];
	answer2 = ps[n - 1][n - 1];
	cout << answer2 << endl;
	return 0;
}



