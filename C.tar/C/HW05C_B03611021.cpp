// HW05C_B03611021.cpp : �w�q�D���x���ε{�����i�J�I�C
//PROGRAMMER:�i�`��
//DATE:2017.12.6
//FILENAME:HW05C_B03611021.cpp
//DESCRIPTION:Magic square

#include "stdafx.h"
#include <iostream>
#include <iomanip>

using namespace std;


int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner



int main()
{

  int numN,col,row=0;
  do{
  cout << "Enter the number of grades to be processed: ";
  cin  >> numN;
  }
  while(numN%2==0);				//check numN
  
  int **magic = new int*[numN];  // create the array

  for(int i=0;i<numN;i++){       
	  magic[i]=new int [numN];
						}
	 magic[0][numN/2]=1; //fill 1 in 
	 col=numN/2;		//set column location
	 int num=1;			//number to fill in
	 int total=1;		//times have filled

	 do
	 {
		 num++;
		 total++;
		 row--;
		 col++;
		 if(total%numN==1){    //already filled
			 row+=2;
			 col--;
			
		 }
		else{
			if(row==-1){     //move off the top
			 row=numN-1;
			 
			 }
			 if(col==numN){   //move off the right
			 col=0;
			 
			}
		 }
		 magic[row][col]=num;
	 }
	 while(total!=numN*numN);
	 
	 answer1=magic[0][0];
	 answer2=magic[numN-1][numN-1];

	 for(int a=0;a<numN;a++){
		 for(int b=0;b<numN;b++){
			 cout<<setw(3)<<magic[a][b];
		 }
		 cout<<endl;
	 }
delete[] magic;
system("pause");
return 0;
}


