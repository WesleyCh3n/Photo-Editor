//  PROGRAMMER : YUSAM HSU
//  DATE       : 2017-12-04
//  FILENAME   : HW05CB05613032
//  DESCRIPTION:the magic sqaure

#include <iostream>
#include <iomanip>
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner
int a,b;       //store the position

int main() {
    int x,y;       //(x,y)
    int i,j;
    int N;         //input by user
    int **arr;     // two dimension array
    for(i=0;;i++)     //input N (odd number)
    {
    cout<<"plaese input a odd number\n";
    cin>>N;
        if(N%2==1)
        {
            break;
        }
    }
    arr = new int*[N];
    
    for( i = 0 ; i < N; i ++)
    {
        arr[i] = new int[N];
    }
    for(i=0;i<N;i++)           //initialize
    {
        for(j=0;j<N;j++)
        {
           arr[i][j]=0;
        }
    }
    x=0;
    y=N/2;
    arr[x][y]=1;
    for(i=2;i<=N*N;i++)  // magic square rule
    {
        a=x;
        b=y;
        x=x-1;
        y=y+1;
        if(x<0)
        {
            x=N-1;
        }
        if(y==N)
        {
            y=0;
        }
        if(arr[x][y]!=0)
        {
            x=a+1;
            y=b;
        }
        //cout<<x<<" "<<y<<endl;
        arr[x][y]=i;
    }
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            cout<<setw(3)<<arr[i][j]<<" ";
        }
        cout<<"\n";
    }
    answer1=arr[0][0];
    answer2=arr[N-1][N-1];
    cout<<answer1<<" "<<answer2;
    for( i = 0 ; i < N; i++)
    {
        delete[] arr[i];
        
    }
    delete[] arr;
    
    return 0;
}
