//================================================================
//  PROGRAMMER : 陳怡孜
//  DATE                   : 2017-12-8
//  FILENAME         : HW05CB06611004.CPP 
//  DESCRIPTION   : This is a program that constructs and displays a magic square for any given odd number N
//================================================================
// HW05CB06611004.cpp : 定義主控台應用程式的進入點。
//

#include "stdafx.h"
#include <iostream>
using namespace std;
#include <iomanip>
int answer1;
int answer2;

int main()
{
	int N;
	cin >> N;

	int M[1000][1000] = { 0 };
	//to declare a 1000*1000 array
	for(int a=1;a<(N*N+1);a++)
	{
		static int i = 0;
		static int j = N / 2;
		if(M[i][j]==0)
		{
			M[i][j] = a;
		}
		else
        //when the position is already filled or out of the upper-right corner. Then place the next number, x+1, immediately below x
		{
			i = i + 2;
			//(compare to the up one row and the right one column)
			j--;
			M[i][j] = a;
		}
		if (i==0&&j==N-1)
		//discuss the stituation
		{
			i = 1;
		}
		else
		{
			if(i==0)
				//the excecption of the first row
			{
				i = N - 1;
			}
			else
			{
				i--;
			}
			if (j==N-1)
				//the exception of the last row
			{
				j = 0;
			}
			else
			{
				j++;
			}
		}
	}

	for (int a=0;a<N;a++)
	{
		for (int b = 0;b<N;b++)
		{
			cout << setw(2) << M[a][b];
			//to display the array
		}
		cout << endl;
	}
	answer1 = M[0][0];
	//Store the integer value of the cell at the top-left corner
	answer2 = M[N - 1][N - 1];
	//Store the integer value of the cell at the bottom-right corner

    return 0;
}

