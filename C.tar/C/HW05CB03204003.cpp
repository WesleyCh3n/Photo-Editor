//================================================================
//  PROGRAMMER : Kuo Chih Ching
//  DATE       : 2017-12-07
//  FILENAME   : HW05CB03204003.CPP
//  DESCRIPTION: This is a program to show a N*N magic square
//================================================================
#include<iostream>
#include<iomanip>
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner
using namespace std;

int main()
{
    int N;
    
    cout<< "Please enter an odd integer N to show a N*N magic square matrix : ";
    cin>>N;
    
    int MagicSquare[N][N];
    
    for(int i = 0; i < N; i++) {
        for(int j = 0; j < N; j++) {
            MagicSquare[i][j] = 0;
        }
    }
    int i =0 ;
    int j= N / 2;//start with MagicSquare[0][N/2]
    
    for ( int value = 1; value <= N*N; value++ )
    {
        MagicSquare[i][j] = value;
        i = i - 1; // up
        j = j + 1; // right
        if (i < 0) { // if over the top
            i = N - 1; // put in the bottom space
        }
        if (j == N) { //if there is no more right column
            j = 0; // put in the left column
        }
        if (MagicSquare[i][j]  == 0) { // if the space has no value
            MagicSquare[i][j]  = value; // put value in
        }
        else if(MagicSquare[i][j]  != 0) {
                i = i + 1;
                MagicSquare[i][j]  = value; // put value in MagicSquare[i][j]
            }
        
        
    }
    
    
    for(int x=0; x<N; x++){
        for(int y=0; y<N; y++){
            cout << MagicSquare[x][y]<<" ";
        }
        cout << endl;
        answer1=MagicSquare[0][0];
        answer2=MagicSquare[N-1][N-1];
    }
    return 0;
}

