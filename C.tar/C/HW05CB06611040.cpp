// HW05CB06611040.cpp : Defines the entry point for the console application.
//================================================================
//  PROGRAMMER : CHEN,Chun-Po
//  DATE : 2017-12-10
//  FILENAME : HW05CB06611040.CPP 
//  DESCRIPTION : This is a program to make a magic square.
//================================================================


#include "stdafx.h"
#include "iostream"
#include "iomanip"
using namespace std;

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main()
{
	int N = 0; //Size of the magic square.
	int row;
	int i, j;
	int n; //The number.
	int **square; //This is the magic square.
	
	cout << "Input an odd number to make a magic square.";
	cin >> N;
	if (N % 2 == 0)
	{
		cout << "Input an odd number to make a magic square.";
		cin >> N;
	}
	if (N % 2 == 0)
	{
		cout << "Input an odd number to make a magic square.";
		cin >> N;
	}
	cout << endl;

	square = new int *[N];
	for (row = 0; row < N; row++)
	{
		square[row] = new int[N];
	}
	for (i = 0; i < N; i++)
	{
		for (j = 0; j < N; j++)
		{
			square[i][j] = 0;
		}
	}

	square[0][N / 2] = 1;
	int y = 0, x = (N / 2); //The place of the number(use x axis & y axis).
	for (n = 2; n <= (N*N); n++)
	{
		if ((y == 0) && (x < (N - 1)))
		{
			x += 1;
			y = (N - 1);
			if (square[y][x] > 0)
			{
				x -= 1;
				y = 1;
			}
			square[y][x] = n;
		}
		else if ((x == (N - 1)) && (y > 0))
		{
			x = 0;
			y -= 1;
			if (square[y][x] > 0)
			{
				x = (N - 1);
				y += 2;
			}
			square[y][x] = n;
		}
		else if ((y == 0) && (x == (N - 1)))
		{
			x = 0;
			y = (N - 1);
			if (square[y][x] > 0)
			{
				x = (N - 1);
				y = 1;
			}
			square[y][x] = n;
		}
		else
		{
			x += 1;
			y -= 1;
			if (square[y][x] > 0)
			{
				x -= 1;
				y += 2;
			}
			square[y][x] = n;
		}
	} //How we place the number.

	for (i = 0; i < N; i++)
	{
		for (j = 0; j < N; j++)
		{
			cout << setw(4) << square[i][j];
		}
		cout << endl;
	} //Display the numbers.

	answer1 = square[0][0];
	answer2 = square[N - 1][N - 1];


	for (row = 0; row < N; row++)
	{
		delete[] square[row];
		delete[] square;
		square = 0;
	} //Delete the space we do not need.
	
    return 0;
}

