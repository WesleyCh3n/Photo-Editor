// HW05CB06611012.cpp : 定義主控台應用程式的進入點。
//================================================================
//  PROGRAMMER : Fei Yueh Chen
//  DATE                   : 2017-12-7
//  FILENAME         : HW05CB06611012.CPP 
//  DESCRIPTION   : Write a program that constructs and displays a magic square for any given odd number N
//================================================================

#include "stdafx.h"
#include <iostream>
#include <new>
using namespace std;

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner
int main()
{
	int N;
	cout << "enter an odd number" << endl;
	cin >> N;
	cout << endl;
	if (N % 2 == 0)//just odd number
	{
		cout << "it's not an odd number" << endl;
		//return 0;
	}
	N = 3;
	int **a = new int*[N];//create a two-dimentional N*N array 
	for (int i = 0; i < N; i++)
		a[i] = new int[N];
	a[0][0] = 0;
	
	for (int i = 0; i < N; i++)//set all into 
	{
		for (int j = 0; j < N; j++)
		{
			a[i][j] = 0;
		}
	}



	//a[0][N / 2] = 1;
	int x = 0;
	int y = N / 2;
	for (int i = 1; i <= N*N; i++)
	{
		if (a[x][y] != 0)//You move to a position that is already filled or out of the upper-right corner. Then place the next number, x+1, immediately below x.
			x++;
		
		a[x][y] = i;
		if (x == 0)
			x = N - 1;//(5)	You move off the top (row = -1) in any column. Then move to the bottom row and place the next number, x+1, in the bottom row of that column.
		else
			x--;
		if (y == N - 1)//(6)	You move off the right end (column = N) of a row. Then place the next number, x+1, in the first column of that row.
			y = 0;
		else
			y++;
		
	}

	for (int i = 0; i < N; i++)//cout square
	{
		for (int j = 0; j < N; j++)
		{
			cout << a[i][j] << " ";
		}
		cout << endl;
	}
	answer1 = a[0][0];
	answer2 = a[N - 1][N - 1];

	for (int i = 0; i < N; i++)
	{
		delete[]a[i];//return the storge to the heap
	}
	delete[]a;
	system("pause");
	return 0;
}