//================================================================
//  PROGRAMMER :  PAN,ZIH-MIN  
//  DATE                   : 2017-12-02
//  FILENAME         : HW05CB06611046.CPP 
//  DESCRIPTION   : This is a program to construct and display a magic square for any given odd number N
//================================================================

#include "stdafx.h"
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner
int main()
{
	int N, m, n;
	cout << "Please enter an odd number" << endl;
	cin >> N;
	cout << "A magic square for " << N << endl;
	int** a;//A magic square
	int** b;//to check whether the position have been filled or not 
		a = new int*[N];//place an one dimension array that have N element and every element is point to int
		for (int s = 0; s< N; ++s)
		{
			a[s] = new int[N]; //put each point to int element in place to point every one dimension array 
		}
		b = new int*[N];//place an one dimension array that have N element and every element is point to int
		for (int t = 0; t< N; ++t)
		{
			b[t] = new int[N];//put each point to int element in place to point every one dimension array 
		}
	m = 0;//Insert the value 1 in the middle of the first row
	n = N / 2;
	a[m][n] = 1;
	b[m][n] = 1;
	for (int i = 2; i <= N*N; i++)
	{
		if (m - 1 >= 0 && n + 1 < N&&b[m - 1][n + 1] != 1)
		{
			m = m - 1; //After a value, x, has been placed, move up one row and to the right one column.Place the next number, x + 1, there
		    n = n + 1;
		}
		else if (m == 0 && n + 1 < N&&b[N - 1][n + 1] != 1)//if move off the top (row = -1) in any column. 
		{
		    m = N - 1;//Then move to the bottom row and place the next number, x+1, in the bottom row of that column.
			n = n + 1;
		}
		else if (m - 1 >= 0 && n == N - 1&&b[m - 1][0] != 1)//if move off the right end (column = N) of a row.
		{
			m = m - 1;// Then place the next number, x+1, in the first column of that row.
			n = 0;	
		}
		else m = m + 1;//if move to a position that is already filled or out of the upper-right corner. Then place the next number, x+1, immediately below x.
		a[m][n] = i;
		b[m][n] = 1;
	}
	for (int s = 0; s < N; s++)
	{
		cout << endl;
		for (int t = 0; t < N; t++)
			cout << setw(4) << a[s][t];
	}
	answer1 = a[0][0];
	answer2= a[N-1][N-1];
	for (int i = 0; i < 10; ++i)
	{
		delete[]a[i]; //delete the one-dimension array that each element point
		delete[] b[i];
	}
	delete[] a;//delete all array
	delete[] b;
	return 0;
}



