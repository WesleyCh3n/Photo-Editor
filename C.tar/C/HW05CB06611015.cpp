// HW05CB06611015.cpp
//================================================================
//  PROGRAMMER : YEN AN CHEN
//  DATE : 2017-12-4
//  FILENAME : HW05CB06611015.CPP 
//  DESCRIPTION :Magic square 
//================================================================


#include "stdafx.h"
#include <iostream>
#include <iomanip>
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main()
{
	int n;//declare n
	cout << "Please input an odd for the side of the square.  ";//the screen display the string above on the screen
	cin >> n;//user input value for n
	cout << endl;//jump to next row
	int **N = new int *[n];//declare N and return the address of the first reserved location in n
	for (int k = 0; k < n; k++)//this for loop is to make the number in array to  return the address of the first reserved location
	{
		N[k] = new int[n];// return the address of the first reserved location
	}
	for (int t = 0; t<n; t++)//this for loop is to make every number in the array is equal to 0
	{
		for (int s = 0; s<n; s++)//this for loop is to make every number in the array is equal to 0
			N[t][s] = 0;//in the array[t][s] is equal to 0
	}

	int i = 0;//the first row
	int j = n / 2;//middle place in the row

	N[i][j] = 1;//this equation is to make the middle number at first row  =1
	for (int a = 2; a <= n*n; a++)//this for loop is to select what number shoud be placed 
	{
		if (a%n == 1)//if a divide n 's reminder is 1,the program will execute the following formula
		{
			i = i + 1;
			N[i][j] = a;//the number will be place in the next row
		}

		else if (i == 0)//if i is equal to 0,the program will execute the following formula
		{
			i = n - 1;
			j = j + 1;
			N[i][j] = a;//the number will be place in the last-two row ,right place
		}

		else if (j == (n - 1))//if j is equal to n-1,the program will execute the following formula
		{
			i = i - 1;
			j = 0;
			N[i][j] = a;//the number will be placed in the front and first row 
		}
		else//the condition that is not mentioned above ,the program will execute the following formula
		{
			i = i - 1;
			j = j + 1;
			N[i][j] = a;//the number will be placed in the front,right row
		}
	}

	for (int b = 0; b<n; b++)//this for loop is to display the number which is processd on the screen
	{
		for (int c = 0; c<n; c++)//this for loop is to display the number which is processd on the screen
		{
			cout << setw(3) << N[b][c];//the number which is processed will be display on the screen
		}
		cout << endl;//jump to next row
	}

	answer1 = N[0][0];//the integer value of the cell at the top-left corner
	answer2 = N[n - 1][n - 1];//the integer value of the cell at the bottom-right corner

	for (int z = 0; z<n; z++)//this for loop is to return the storage to the heap
		delete[] N[z];// return the storage to the heap
	delete[] N;// return the storage to the heap
	return 0;
}


