// HW05CB06611035.cpp : Defines the entry point for the console application.
//================================================================
//  PROGRAMMER :WENG,YU-TING
//  DATE                   : 2017-12-06
//  FILENAME         : HW05CB06611035.CPP 
//  DESCRIPTION   : This is program of magic square.
//================================================================

#include "stdafx.h"
#include "iostream"
#include "iomanip"
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner



int main()
{
	int x,y; //x is the colunm, y is the row of the place now.
	int i,j; //declare the variables used in the for loop to initialize the array with 0
	int k,m; //declare the variables used in the for loop to output the array
	int n = 1; //the number from 1 to N placed in the array 
	int N = 0; //the size of the array
	cout << "Please input an odd number : "<<endl;
	cin >> N; 
	int **square;   //create a two-dimention dynamic array
	square = new int *[N];
	for (int row = 0; row < N; row++) {
		square[row] = new int[N];
	}
	for (i = 0; i < N; i++) {  //initialize the array
		for (j = 0; j < N; j++) {
			square[i][j] = 0;
		}
	}
	square[0][N / 2] = 1;  //put the value 1 in the middle of the first row
	x = N / 2;
	y = 0;
	for (n = 2; n <= (N*N); n++) { //use the rule given to place the value from 2 to N
		x = x + 1;
		y = y - 1;
		if (x > (N - 1)) {
			x = x - N;
		}
		if (y < 0) {
			y = y + N;
		}
		if (square[y][x] == 0) {
			square[y][x] = n;
		}
		else {
			y = y + 1;
			if (y > (N - 1)) {
				y = y - 3;
				square[y][x] = n;
			}
			else  square[y][x] = n;
		}
	}

	for (k = 0; k < N; k++) {   //output the array
		for (m = 0; m < N; m++) {
			cout << setw(3)<<square[k][m]<<" ";
		}
		cout <<"\n";
	}

	answer1 = square[0][0];
	answer2 = square[N - 1][N - 1];

	for (int row = 0; row < N; row++) {  //delete the dynamic array
		delete[] square[row];
		delete[] square;
		square = 0;
	}


    return 0;
}

