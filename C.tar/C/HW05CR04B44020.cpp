//================================================================
//  PROGRAMMER    : James Wu
//  DATE          : 2017-12-05
//  FILENAME      : HW05CR04B44020.CPP
//  DESCRIPTION   : This is a program that constructs and displays a magic square for any given odd number N.
//================================================================

#include "stdafx.h"
#include <iostream>
#include <new>
using namespace std;

int answer1;
int answer2;

int main()
{
	int N;
	int ROWS, COLS;
	int i, j;
	int x; // Number (from 1 to N*N)

	cout << "Enter an odd number N: ";
	cin >> N;

	ROWS = N;
	COLS = N;

	int **ELEMENT = new int*[ROWS];
	for (int i = 0; i < ROWS; i++)
		ELEMENT[i] = new int[COLS];

	// Set all elements to zero
	for (int i = 0; i < ROWS; i++)
	{
		for (int j = 0; j < COLS; j++)
		{
			ELEMENT[i][j] = 0;
		}
	}
	
	ELEMENT[0][N / 2] = 1;

	// Set initial position
	i = 0;
	j = N / 2;

	for (x = 2; x <= N * N; x++)
	{
		if (ELEMENT[i - 1][j + 1] == 0)
		{
			ELEMENT[i - 1][j + 1] = x;
			i = i - 1;
			j = j + 1;
		}
		if (ELEMENT[i - 1][j + 1] != 0)
		{
			ELEMENT[i + 1][j] = x;
			i = i + 1;
		}
		if (i - 1 == -1)
		{
			ELEMENT[N - 1][j + 1] = x;
			i = N - 1;
			j = j + 1;
		}
		if (j + 1 == N)
		{
			ELEMENT[i - 1][0] = x;
			i = i - 1;
			j = 0;
		}
	}

	for (int i = 0; i < ROWS; i++)
	{
		cout << endl;
		for (int j = 0; j < COLS; j++)
		{
			cout << ELEMENT[i][j];
		}
	}

	answer1 = ELEMENT[0][0];
	answer2 = ELEMENT[N][N];

	for (int i = 0; i < ROWS; i++)
	{
		delete[] ELEMENT[i];
	}
	delete[] ELEMENT;
	
	return 0;
}

