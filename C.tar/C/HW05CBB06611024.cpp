//=========================================================================================
//PROGRAMMER :LAU SHING FUNG
//DATE       :2017-12-6
//FILENAME   :HW05CB06611024
//DESCRIPTION:THIS PROGRAM IS USE TO FIND OUT THE MAGIC SQUARE
//=========================================================================================

#include "stdafx.h"
#include <iostream>
#include <cmath>
#include<iomanip>
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner



int main()
{
	int N;
	
	int number;
	int i ,j ,k ,l = 0;
	cout << "Please input the size of the magic square :";
	cin >> N;//ask for a number
	for (;N % 2 == 0;)
	{
		cout << "Error! Please input a odd number :";
		cin >> N;//if the user input an even number it will warning the user
	}

	int **square;
	square = new int*[N];
	for (i = 0; i < N; i++)
		square[i] = new int[N];//declaration of a dynamic two-dimensional arrays
	
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
			square[i][j]=0;//initialize of the arrays
	
	for (number = 1; number <= (N*N); number++)
	{
		if (number == 1)
		{
			i = 0;
			j = N / 2;//input the first number into the square
		}
		
		
		else if (number != 1)//start input the second number to the last number
		{
			
			if (i < 0)
				i = N-1;
		    if (j > N-1)
				j = 0;
			if (square[i][j] != 0)//if already have a number inside the box, it will directly move to it's below
			{
				i = k + 1;
				j = l;
			}
			
		}
		

		square[i][j] = number;//insert the number
		k = i;
		l = j;
		i--;
		j++;
	}

	for (i = 0; i < N; i++)
	{
		for (j = 0; j < N; j++)
			cout << setw(3) << square[i][j];//show the result magic square
		cout << endl;
	}

	answer1 = square[0][0];
	answer2 = square[N - 1][N - 1];
	cout << "The number of top-left is :" << answer1 << endl;
	cout << "The number of bottom-right is :" << answer2 << endl;
	for (i = 0; i < N; i++)
		delete[]square[i];
	delete[]square;//release the memory of the arrays


    return 0;
}

