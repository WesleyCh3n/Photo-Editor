//
//  main.cpp
//  HW05BB03208026
//================================================================
//  PROGRAMMER : SUN, WEI LUN
//  DATE                   : 2017-11-29
//  FILENAME         : HW05CB03208026.CPP
//  DESCRIPTION   : Magic square
//================================================================


#include <iostream>
#include <string>
#include <iomanip>

int answer1, answer2;

using namespace std;


int main()
{
    int N;
    cout << "請輸入方陣階數:";
    cin >> N;
    int A[N][N];
    
    int r = 0;
    int c = (N-1)/2;
    int v = 1;
    
    for(int i = 0; i < N; i++)  // fill in 0 in square.
    {
        for(int j =0; j<N; j++)
        {
            A[i][j] = 0;
        }
    }
    
    
    
    for(;v<=(N*N);) // fill in all the numbers in square with magic square rules.
    {
        A[r][c] = v;  //first, row 1, column2, input as 1, than input other numbers: 5, 6,
        v++;
        
        r--;  //move to the up, right square.
        c++;
        
        if((r < 0)&&(c <= N-1)){  //number 2. You move off the top (row = -1) in any column. Then move to the bottom row and place the next number, x+1, in the bottom row of that column.
            r = N-1;
        }
        else if ((r>=0) && (c > N-1)){  //number 3, 8. You move off the right end (column = N) of a row. Then place the next number, x+1, in the first column of that row.
            c = 0;
        }
        else if((r < 0)&&(c > N-1)){ // number 7,
            r = r+2;
            c--;
        }
        else if(A[r][c]!= 0){ //number 4, You move to a position that is already filled or out of the upper-right corner. Then place the next number, x+1, immediately below x
            r = r+2;
            c--;
        }
    }
    
    
    
    for(int i=0; i<N; i++)   // show the magic array.
    {
        for(int j=0; j<N; j++)
        {
            cout << setw(4)<<A[i][j] ;
        }
        cout << endl;
    }
    
    
    answer1=A[0][0];
    answer2=A[N-1][N-1];
    
    
    
    return 0;
}
