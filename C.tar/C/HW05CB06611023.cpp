//================================================================
//  PROGRAMMER : 郭元媛
//  DATE       : 2017-12-04
//  FILENAME   : HW05CB06611023.CPP
//  DESCRIPTION: This is a program to output a magicsquare NxN
//================================================================

#include <iostream>
#include <iomanip>

using namespace std;

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main() {
    
    int N;
    int row, col;
    
    cout<<"The magic square with rows and colums N. The N that you want is (It must be an odd number!):"<<endl;
    
    cin>>N;
    cout<<endl;
    
    if (N%2==0) { //if the number is an even number
        return 0;
    }
    
    int MagicSquare[N][N];
    
    for (row=0; row<N; row++) { //Give the array a value
        for (col=0; col<N; col++) {
            MagicSquare[row][col]=0;
        }
    }
    
    MagicSquare[0][N/2]=1;
    
    row=0;
    col=(N-1)/2;
    
    for (int i=2; i<=(N*N); i++) {
        
        row=row-1;
        col=col+1;
        
        if (row==-1 && col==N) { //Upper right corner
            row=row+2;
            col=col-1;
        }
        
        if (row==-1) {
            row=(N-1);
        }
        if (col==N) {
            col=0;
        }
        
        if (MagicSquare[row][col]!=0) { //Already filled out
            row=row+2;
            col=col-1;
        }
        
        MagicSquare[row][col]=i;
        
    }
    
    for (row=0; row<N; row++) { //Output of the Magic Square
        for (col=0; col<N; col++) {
            cout<<setw(5)<<MagicSquare[row][col];
        }
        cout<<endl;
    }
    
    answer1=MagicSquare[0][0];
    answer2=MagicSquare[N-1][N-1];
    
    return 0;
}
