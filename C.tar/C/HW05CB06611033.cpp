//  PROGRAMMER : BRYAN HOU
//  DATE                   : 2017-12-07
//  FILENAME         : HW05CB06611033.CPP 
//  DESCRIPTION   : This is a program to show a magic square

#include <iostream>
#include <iomanip> 
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main()
{
	int n;        //declare an integer
	cout<<"please input the length of the magic cube";    //give instructions
	cin>>n;          //input the square length
	int square [n][n];      //declare a square array
	for (int i=0;i<n;i++)    //initialize the all the values in the array to 1
	{
		for(int j=0;j<n;j++)
		{
		 square [i][j]=0;
		}
	}
	square [0][n/2]=1;     //store 1 into the middle of the first row
	int r=0;            //store the row position into r
	int c=n/2;        //store the column position into c
	for (int i=2;i<=n*n;i++)      //give values to the elements in the array according to the rules
	{
	  if (square [(r-1+n*n)%n][(c+1)%n]==0)
	  {
	    square [(r-1+n*n)%n][(c+1)%n]=i;
		r--;
		c++;
		
	  }
	  else if (square [(r-1+n*n)%n][(c+1)%n]!=0)
	  {
	   square [(r+1+n*n)%n][c%n]=i;
	   r++;
	   
	  }
	 
	}
	cout<<"the magic cube is"<<endl;   //to tell whats going to be outputted
	for (int i=0;i<n;i++)      //output the magic square
	{
		for(int j=0;j<n;j++)
		{
		 cout<<setw(4)<<square[i][j];
		}
	  cout<<endl;
	}
	answer1=square [0][0];   // Store the integer value of the cell at the top-left corner into answer1
	answer2=square [n-1][n-1];   // Store the integer value of the cell at the top-left corner into answer2
	return 0;
}
