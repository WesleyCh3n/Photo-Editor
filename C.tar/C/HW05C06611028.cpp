//PRogrammer:Yu,tsung-en
//Date:20171205
//Filename:HW05CB06611028
//Desctiption:print the magic square.
//#include "stdafx.h"
#include"iostream""
#include"iomanip""
using namespace std;
int answer1, answer2,n,c,h,i,j;
int main()
{ 
  

  cout<< "Please enter an odd integer: ";
  cin>>n;
  if (n/2==0)
  cout<<"This is not an odd number.";
  int square[n][n];    //reset the square value. 
  for( i = 0; i < n; i++) 
   for( j = 0; j < n; j++) 
      square[i][j] = 0;
  int newrow, newcol;  //the next one position   
  int i=0;   
  int j=n/2;//set the position of 1
  for ( int val=1; val<=n*n; val++)  
  { 
     if(square[i][j]!=0)   //if the next position already have number.
    {
      if(i==n-1&&j==0)//the top-right value.
      {
      	square[1][n-1]=val;
      	newrow=0;
      	i=newrow;
      	newcol=0;
      	j=newcol;
      	continue;
	  }
	  if (i==n-1)//the right column.
	  {
	  	square[1][j-1]=val;
	  	newrow=0;
	  	i=newrow;
	  	newcol=j;
	  	j=newcol;
	  	continue;
	  }
	  square[i+2][j-1]=val;
	  newrow=i+1;
	  i=newrow;
	  newcol=j;
	  j=newcol;
      continue;
	  }
	 square[i][j]=val;   //from 1 to n square.
	 newrow =i-1; 
	 newcol =j+1;
	 if(newrow<0 &&newcol==n)  //if the position is top row or right column 
	   {
	   	 newrow=n-1;
	   	 i=newrow;
	   	 newcol=0;
	   	 j=newcol;
	   	 continue;
	    	}
	 if(newrow<0&&newcol<n)
	   {
	 	 newrow=n-1;
	   	 i=newrow;
	   	 j=newcol;
	   	 continue;
		    } 
	 if(newrow>=0&&newcol==n)
       {
       	i=newrow;
       	newcol=0;
	   	j=newcol;
	   	continue;
		   }
	  i=newrow;
	  j=newcol;	   
	 
  }
 for (c=0;c<n;c++)  //print the array 
    {
	 for(h=0; h<n;h++)
	 cout <<setw(3)<<square[c][h]<<"  ";
     cout <<endl;
	 }	
answer1= square[0][0];
answer2= square[n-1][n-1];
return 0;
}
