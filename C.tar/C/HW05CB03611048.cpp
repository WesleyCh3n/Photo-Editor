//====================================================================================
//  PROGRAMMER : �i���X
//  DATE       : 2017-12-05
//  FILENAME   : HW05CB03611048.CPP 
//  DESCRIPTION: This is a Magic Square Program.
//=====================================================================================
// HW05CB03611048.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "iostream"
using namespace std;

int n;
int answer1;
int answer2;

int main()
{
	cin >> n;

	int array[n][n];
	
	//initialize all element to 0
	memset(array,0,sizeof(array));
	
	int row = 0;
	int col = n/2;
	int num = 1;

	array[row][col] = num;
	num++;
	
	while(num <= n*n)
	{
		row--;
		col++;

		if(row < 0 && col == n)
		{
			row += 2;
			col--;
		}
		else if(row < 0) 
		{
			row = n-1;
		}
		else if(col == n)
		{
			col = 0;
		}
		else if(array[row][col] != 0)
		{
			row += 2;
			col--;
		}

		array[row][col] = num;

		if(row == 0 && col == 0) answer1 = num;
		if(row == n-1 && col == n-1) answer2 = num;
		num++;
	}

	/*for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			cout << array[i][j] << " ";
		}
		cout << endl;
	}

	cout << answer1 << " " << answer2 << endl;*/
	return 0;
}


