//==========================================================================================================================================
//PROGRAMMER : LI JING CHUN
//DATE       : 2017 - 12 - 06
//FILENAME   : HW05CB06611021.CPP
//DESCRIPTION: This program allows the user to input an odd number N then constructs and displays a magic square with N rows and N columns. 
//===========================================================================================================================================


#include "stdafx.h"
#include "iostream"
#include "iomanip"

using namespace std;

int answer1; //Stores the integer value of the cell at the top-left corner
int answer2; //Stores the integer value of the cell at the bottom-right corner

int main()
{
	int N; //Stores the value of rows and columns input by the user

	cout << "Enter an odd number for the number of rows and columns:";  //Allows the user to input the value of N
	cin >> N;

	if (N % 2 == 1) //Check if the input is an odd number
	{
		int **square = new int*[N]; //Makes a two-dimensional array using the input
		for (int i = 0; i < N; i++) 
			square[i] = new int[N];
		square[0][N / 2] = 1; //Put 1 in the middle of the first row
		int a = N / 2; //Finds the middle part of columns
		int b = 0; //Use to represent which row is being used
		int num = 1; //The number to be placed 

		while (1) //An infinite loop
		{
			num++; //Adds to the value of the number each loop

			if (num%N == 1) //Check if it is needed to move to the next row
			{
				b++;
			}
			else //Puts the value of the number to the upper right array
			{
				b--;
				a++;
			}

			if (b < 0) //When the row exceeded the rows in the square
			{
				b= N - 1;
			}

			if (a > N - 1) //When the column exceeded the columns in the square
			{
				a = 0;
			}
			square[b][a] = num; //Stores the current number in the array

			if (num == N*N) //Ends the infinite loop after all the values are placed
			{
				break;
			}
		}

		for (int i = 0; i < N; i++) //Displays the arranged array (magic square)
		{
			cout << endl; //Moves to the next row
			for (int j = 0; j < N; j++)
			{
				cout << setw(4) << square[i][j];
			}
		}
	
		answer1 = square[0][0]; 
		answer2 = square[N - 1][N - 1];

		for (int i = 0; i < N; i++) //Clears the memory
		{
			delete[] square[i];
		}
		delete[] square;
		
	}

	else //Invalid Input
	{
		cout << "Invalid input";
	}

	system("pause");
    return 0;
}

