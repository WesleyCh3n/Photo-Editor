//================================================================
//  PROGRAMMER : Bo Kuan Liu
//  DATE                   : 2017-11-27
//  FILENAME         : HW05CR04543043.CPP 
//  DESCRIPTION   : This is a program to constrct magic square
//===============================================================


#include "stdafx.h"
#include<iostream>
#include<iomanip>
using namespace std;

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner


int main()
{
	int N;
	int i, j;
	int x=0;
	cin >> N;
	int** magic=new int*[N];//allocate a 1-D array that it's size is determined by input,and each element is point to integer
	for (i=0;i<N;i++)
	{
		magic[i] = new int[N];//let each pointer point to a 1-D array that it's size is determined by input
	}

	int newrow=0, newcolumn=N/2;
	for (i=0;i<N;i++)
	{
		for (j=0;j<N;j++)
		{
			magic[i][j] = 0;//initialization of 2-D array
		}
	}
	magic[0][N/2] = 1;//first rule
	
	for (i=1;i<N*N;i++)
	{
		
		newrow = newrow - 1;
		newcolumn = newcolumn + 1;
		//avoid coordinate from exceeding boundary
		if (newrow < 0) newrow = newrow + N;
		if (newcolumn > N-1) newcolumn = newcolumn - N;
		if (newrow > N-1) newrow = newrow - N;
		if (newcolumn < 0) newcolumn = newcolumn +N;
		//rule
		while (magic[newrow][newcolumn] != 0)
		{
			if (x >= 1) newrow = newrow + 1;
			if (x == 0)
			{
				newrow = newrow + 2;
				newcolumn = newcolumn - 1;
				if (newrow < 0) newrow = newrow + N;
				if (newcolumn > N - 1) newcolumn = newcolumn - N;
				if (newrow > N - 1) newrow = newrow - N;
				if (newcolumn < 0) newcolumn = newcolumn + N;
				x ++;
			}
		}
		x = 0;
		magic[newrow][newcolumn] = i + 1;
	}
	answer1 = magic[0][0];
	answer2 = magic[N-1][N-1];
	for (i=0;i<N;i++)
	{
		for (j=0;j<N;j++)
		{
			cout <<setw(3)<< magic[i][j];//display
		}
		cout << endl;
	}

	for (int i = 0; i < N; i++)
	{
		delete[] magic[i]; 
	}
	delete[] magic; 

	return 0;
}


