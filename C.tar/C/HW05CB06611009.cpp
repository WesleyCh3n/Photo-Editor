//================================================================
//  PROGRAMMER : Chen Juo Tung
//  DATE: 2017-12-6
//  FILENAME: HW05CB06611009.CPP
//  DESCRIPTION:  Write a program that constructs and displays a magic square for any given odd number N.
//================================================================

#include "stdafx.h"
#include<iostream>
#include<iomanip>
using namespace std;

int answer1 = 0, answer2 = 0;

int main() {
	//input n to create a nxn size array
		int n, x, y;
		cout << "Please enter the N of magic cube:" << endl;
		cin >> n;
	//declaring a 2D dynamic array
		int **a=new int*[n];
		for (int i = 0;i < n;++i)
		a[i] = new int[n];
	//make "a" become zero
		for (int i = 0;i<n;i++)
			for (int j = 0;j<n;j++)
				a[i][j] = 0;
	//fill "a"by the rules 
		a[0][n / 2] = 1;		 //put 1 in the middle of the first roll 
		x = 0; y = n / 2;		//identify the recent location to be (x,y)
		for (int i = 2;i <= n*n;i++) {
			if (a[(n*n + (x - 1)) % n][(y + 1) % n] == 0) {			 //the situation that the top-right corner has'nt been filled in
				x--; y++;		//update the recent location
				a[(n*n + x) % n][(y) % n] = i;   //and then fill the up-right position with the next number
			}
			else if (a[(n*n + (x - 1)) % n][(y + 1) % n] != 0) {				//the situation that the top-right corner has been filled in 
				x += 1;			//update the recent location
				a[(n*n + (x)) % n][(y) % n] = i;  //and then fill the position below with the next number

			}
		}
	answer1 = a[0][0];				 // Store the integer value of the cell at the top-left corner
	answer2 = a[n - 1][n - 1];	 // Store the integer value of the cell at the bottom-right corner

	//display the magic square 
		cout << "Your magic square is:" << endl;
		for (int i = 0;i<n;i++) {
			for (int j = 0;j<n;j++)
				cout << setw(3) << a[i][j] << " ";
			cout << endl;
		}
	//cleaning up the memory to prevent memory leaking
		for (int i = 0; i < n; ++i) {
			delete[] a[i];
		}
		delete[] a;
	getchar();
	getchar();
    return 0;
}

