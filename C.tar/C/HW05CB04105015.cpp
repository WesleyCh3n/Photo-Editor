//================================================================
//  PROGRAMMER : Chao Pin Chi
//  DATE       : 2017-12-07
//  FILENAME   : HW05CB04105015.CPP
//  DESCRIPTION: This is a magic square
//================================================================
#include <iostream>
using namespace std;

int answer1; // Store the integer value of the cell at the top-left corner
int answer2; // Store the integer value of the cell at the bottom-right corner

int main(int argc, const char * argv[]) {
    int i;
    int j;
    int n;
    int counter;
    int number;
    int **s;
    cout << "please input a number : ";
    cin >> n;
    s = new int*[n];//dynamic array
    for (i = 0; i<n; i++) {
        s[i] = new int[n];
    }
    
    for (i = 0; i<n; i++) {//input the number
        for (j = 0; j<n; j++) {
            s[i][j] = 0;
        }
    }
    
    
    i = 0;
    j = n / 2;//put 1 on the first row midden
    number = 1;
    counter = 1;
    s[i][j] = 1;
    while (counter != (n*n) ) {
        i--;//go to the top right
        j++;//go to the top right
        number++;
        counter++;
        
        if (i < 0 && j >= n) {//aviod number exceeding values
            i += 2;
            j--;
        }
        else if (i < 0) {  //if i < 0 turn to the bottom row
            i = n - 1;
        }
        else if (j >= n) {//if j >= n turn to the first column
            j = 0;
        }
        else if (s[i][j] != 0) {//if s[i][j] have number,change the position
            i += 2;
            j--;
        }
        s[i][j] = number;//put the number in
        
    }
    cout << endl;
    
    for (i = 0; i<n; i++) {//cout the result
        for (j = 0; j < n; j++) {
            cout << s[i][j] << " ";
        }
        cout << endl;
    }

    answer1 = s[0][0];
    answer2 = s[n-1][n-1];
    
    cout << "answer1 is " << answer1 << endl;
    cout << "answer2 is " << answer2;
    delete [] s;
    return 0;
}

