//================================================================
//  PROGRAMMER :HSIEH,MING-HSUAN
//  DATE: 2017-12-06
//  FILENAME: HW05CB05611009.CPP
//  DESCRIPTION: A program that constructs and displays a magic square for any given odd number N.
//================================================================

#include "stdafx.h"
#include<iomanip>
#include<iostream>
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner


int main()
{
	int n, x, y;/*Initail n,x,y*/
	cout << "Please type the length of the width of the sqare (Must be odd number) ";
	cin >> n;
	int** ary = new int*[n];/*Intialing 2D dynamic array*/
	for (int i = 0; i < n; ++i)
		ary[i] = new int[n];
	for (int i = 0; i<n; i++)/*Set all elements at 0*/
		for (int j = 0; j<n; j++)
			ary[i][j] = 0;


	ary[0][n / 2] = 1;  /*Assign 1 to the top middle*/
	x = 0; y = n / 2;   /*Record the location by X,Y*/
	for (int i = 2; i <= n*n; i++) {
		if (ary[(n*n + (x - 1)) % n][(y + 1) % n] == 0) { /*Check if the next move done before*/
			x--; y++; /*Change location*/
			ary[(n*n + x) % n][(y) % n] = i;  /*Fill the next blank*/
		}

		else if (ary[(n*n + (x - 1)) % n][(y + 1) % n] != 0) { /*If the next blank is occupied*/
			x = x + 1; /*Fill the blank beside instead*/
			ary[(n*n + (x)) % n][(y) % n] = i;

		}
	}




	cout << "Your magic cube is:" << endl;/*All about displaying it*/
	for (int i = 0; i<n; i++) {
		for (int j = 0; j<n; j++)
			cout << setw(3) << ary[i][j] << " ";
		cout << endl;
	}

	answer1 = ary[0][0];
	answer2 = ary[n - 1][n - 1];
	
	
	for (int i = 0; i < 5; ++i) {
		delete[] ary[i];
	}
	//Free the array of pointers
	delete[] ary;

	return 0;
}


