//================================================================
//  PROGRAMMER : HUANG SHAO ZHENG
//  DATE : 2017-12-04
//  FILENAME : HW05CB06611010.CPP 
//  DESCRIPTION :Write a program that constructs and displays a magic square for any given odd number N.
//================================================================
#include "stdafx.h"
#include <iostream>
#include <iomanip>
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner


int main()
{
	int n, a, b, m[100][100] = { 0 }, i, j; //declare all the variables I need and claim a space for the array of magic cube
	cout << "Please input the N of the magic cube : ";
	cin >> n;								//input how many you want
	cout << endl;
	m[0][n / 2] = 1;						//set the position of number 1 at top-middle
	a = 0;									//set the present position
	b = n / 2;								//set the present position
	for (i = 2; i <= n*n; i++)
	{
		if (m[(n*n + a - 1) % n][(b + 1) % n] == 0)			//if the position up and right one grid hasn't been input number yet
		{
			a--;							//update the present position
			b++;							//update the present position
			m[(n*n + a) % n][(b) % n] = i;	//input the next number in the position up and right one grid
		}
		else if (m[(n*n + a - 1) % n][(b + 1) % n] != 0)	//if the position up and right one grid had already been input number
		{
			a +=1;							//update the present position
			m[(n*n + a) % n][(b) % n] = i;	//input the next number in the position below (next column)
		}
	}
	cout << "The magic cube is : " << endl;
	for (i = 0; i < n; i++)					//print the magic cube
	{
		for (j = 0; j < n; j++)
		{
			cout << setw(3) << m[i][j] << " ";
		}
		cout << endl;
	}
	answer1 = m[0][0];						//input the number into answer1
	answer2 = m[n-1][n-1];					//input the number into answer2
	cout << endl << "And answer1 is " << answer1 << " answer2 is " << answer2;

    return 0;
}

