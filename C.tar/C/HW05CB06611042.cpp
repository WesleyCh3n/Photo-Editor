//================================================================
//  PROGRAMMER : YEH YENG TUNG
//  DATE        : 2017-11-26
//  FILENAME         : HW05CB06611042.CPP
//  DESCRIPTION   : This is a program to construct and display a magic square
//================================================================

#include <iostream>
#include <iomanip>
using namespace std ;
int answer1 ;
int answer2 ;

int main(void)
{
    int n ;
    while(1){  //decide the size of magic square
        cout << "Please enter the odd number : " ;
        cin >> n ;
        if( n % 2 == 1 )
            break ;
        else
            cout << "It is not a valid number ! " << endl ;
    }
    int matrix[n+1][n+1] ;
    int i = 0 ;
    int j = ( n + 1 ) /  2 ;
    int variable ;
    for( variable = 1 ; variable <= n * n ; variable++ ){ // use magic square algorithm to store each number
        if ( variable % n == 1 )
            i++ ;
        else{
            i--;
            j++;
        }
        
        if ( i == 0 )
            i = n ;
        if ( j > n )
            j = 1 ;
        matrix[i][j] = variable ;
    }
    
    for( int t = 1 ; t <= n ; t++ ){  // print out the magic square
        for( int h = 1 ; h <= n ; h++ )
            cout << setw(5) << matrix[t][h] ;
    cout << endl ;
    }
    answer1 = matrix[1][1] ;
    answer2 = matrix[n][n] ;
    return 0;
}
