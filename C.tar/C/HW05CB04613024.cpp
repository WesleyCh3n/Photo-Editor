//  PROGRAMMER : Chen hong yue
//  DATE                   : 2017-12-07 
//  FILENAME         : HW05CB04613024.CPP 
//  DESCRIPTION   :Magic square

#include<iostream>
#include<iomanip>
#include<math.h>
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner



int main()
{ 
int N ;//numbers of row. & col.
int **M;//declare 2-D array pointer
int i, j, a, b;//i & j for count;a is row. number; b is col. number

cout << "Give me number N : ";//to input N
cin >> N;//The user give N
cout <<"The matrix : "<<endl; //show the matrix below
M = new int*[N];//declare 2-D array pointer
for(i = 0; i < N; i++){//declare 1-D array pointer
	M[i] = new int[N]; 
}
a = 0;//1st row. number
b = N/2;//1st col. number
for(i = 0; i < N; i++){//make each number in matrix is 0 by loop
	for(j = 0; j < N; j++){
		M[i][j] = 0;
	}
}


for(i = 1; i <= pow(N,2); i++){//loop
	M[a][b] = i;//give array number
	
	b += 1;//move to next position
	if(b > N-1)
	b -= N;
	
	a -= 1;
	if(a < 0)
	a += N;

	
	if(M[a][b] != 0){//if next position is occupied, move to the position below
		a += 2;
		b -= 1;
		if(b < 0)
	    b += N;
	    if(a > N-1)
	    a -= N;
	}
}

for(i=0 ; i<N ; i++){//show all number by loop
	for(j=0; j<N ; j++){
		cout << setw(3) << M[i][j] <<" ";
	}
	cout <<endl;
}

answer1 = M[0][0];//store the answer1
answer2 = M[N-1][N-1]; //store the answer1


for(i = 0; i < N; i++){//delete 1-D array by loop
	delete[] M[i]; 
}
delete[] M;//delete 2-D array


	return 0;
}
