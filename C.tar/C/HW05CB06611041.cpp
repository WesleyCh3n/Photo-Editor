// ConsoleApplication17.cpp : �w�q�D���x���ε{�����i�J�I�C
/////================================================================
//  PROGRAMMER : �����v
//  DATE                   : 2017-12-03
//  FILENAME         : HW05AB06611041.CPP 
//  DESCRIPTION   : This is a program to compute magicsquare
//================================================================
#include "stdafx.h"
#include<iostream>
#include<iomanip>
using namespace std;

void magicsquare(int);//declare the function that print the n*n magic square
int ar(int r, int n);//declare the function that display the rule of row
int ac(int c, int n);//declare the function that display the rule of collum

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main()
{
	int n;//define the n*n square
	cin >> n;//let user to input n
	magicsquare(n);
	return 0;
}

void magicsquare(int n) {//the content of magicsquare
	int *arr = new int[n*n];//declare the dynamic array
	int i, j;
	int c = n / 2;//initialize the collum
	int r = 0;//initialize the row
	for (i = 0; i < n; i++)//use nested loop to initialize elements of array
		for (j = 0; j < n; j++)
			*(arr + i*n + j) = 0;
	for (int k = 1; k <= n*n; k++) {//input every elements into array
		*(arr + r*n + c) = k;//the formula of element
		if (*(arr + ar(r, n)*n + ac(c, n)) != 0) {//determine the location
			r = r + 1;
		}
		else {
			r = ar(r, n);
			c = ac(c, n);
		}
	}
	for (i = 0; i < n; i++) {//print elements
		for (j = 0; j < n; j++)
			cout << setw(3) << *(arr + i*n + j) << " ";
		cout << endl;
	}
	answer1 = *(arr);//the formula of answer1
	answer2 = *(arr + (n - 1)*n + (n - 1));//the formula of answer2
	delete []arr;//prevent memory leak

}
int ar(int r, int n) {//the comtent of ar
	if (r - 1 < 0)
		return n - 1;
	else
		return  r - 1;
}
int ac(int c, int n) {//the comtent of ac
	if (c + 1 > n - 1)
		return 0;
	else return c + 1;
}