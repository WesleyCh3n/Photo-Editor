//
//  main.cpp
//  HW05BB06611043
//
//  Created by jimmy yu on 2017/12/5.
//  Copyright © 2017年 jimmy yu. All rights reserved.
//

#include <iostream>
#include <iomanip>
#include <new>
using namespace std;

int answer1,answer2;

void fill(int);  //function prototype

int main()
{
    
    int size;
    
    cout << "Please input the diameter for the magic square : ";  //asking for input
    cin >> size;
    
    fill (size);                                              //filling in the magic square
    
    
    
    return 0;
}





void fill(int num)   //function to fill in the numbers
{
    int row=0, col=0;
    
    int** sqr = new int* [num];            //creating a dynamic two dimensional array
    for (int i=0; i<num; i++)
        *(sqr+i) = new int[num];
    
    for(int i=0; i<num; i++)                    //initialize the whole 2d array
    {
        for(int j=0; j<num; j++)
        {
            *(sqr[i]+j) = 0;                //make each space 0
        }
    }
    
    
    
    for(int i=1; i<=num*num; i++)                   //filling in the spaces
    {
        int rowchec=0, colchec=0;
        
        if (i==1)                                    //start filling in with 1
        {
            *(sqr[0]+ num/2) = 1;
            row = 0;                                //use row and col to store the address of the latest filled number.
            col = num/2;
        }
        else                              //using variables rowchec and colchec to check if a violation exists
        {
            if(row-1<0)                   //checking for the up one row move
                rowchec = num-1;          //when violation occurs, jump to the bottom
            else
                rowchec = row-1;          //normal situation
            
            if (col+1==num)               //checking for the right on column move
                colchec = 0;              //when violation occurs, jump to the left
            else
                colchec = col+1;          //normal situation
            
            if (*(sqr[rowchec]+colchec)!= 0)       //if the space we moved to is occupied
            {
                *(sqr[row+1]+col) = i;             //fill the number in the blank right under its previous number
                row = row+1;                       //dont forget to alter row too!!!!
            }
            else
            {
                row = rowchec;                   //since we're good to go, set row and col to its confirmed address
                col = colchec;
                *(sqr[row]+col) = i;              //and store the number there!!
            }
            
        }
            
    }
    
    
    
    
    for(int i=0; i<num; i++)                    //cout the whole square
    {
        for(int j=0; j<num; j++)
        {
            cout << setw(5) << *(sqr[i]+j);      //cout each space
        }
        cout << endl;
        
        answer1 = *(sqr[0]+0);
        answer2 = *(sqr[num-1]+num-1);
    }
    
    for (int i=0; i<num; i++)
        delete[] sqr[i];                       //!!!!! giving back the occupied int storage memory spaces !!!!!
    
    delete[] sqr;                         //free memory storage for pointers
    return;
}











