// HW05CB06611027.cpp : Defines the entry point for the console application.
//  PROGRAMMER : Chu Yi Tzu 
//  DATE  : 2017-12-07
//  FILENAME : HW01AB06611027.CPP 
//  DESCRIPTION   : This is a program to display an N*N magic square


#include "stdafx.h"
#include<iostream>
#include<iomanip>

using namespace std;
int answer1;// Store the integer value of the cell at the top-left corner
int answer2;// Store the integer value of the cell at the bottom-right corner

int main()
{
	
	
		int i, j;
		int N;
		int **magsquare;

		cout << "Please enter N for a N*N magic square." << endl;
		cin >> N ;

		magsquare = new int*[N];//this is the height
		for (i = 0; i < N; i++)
			magsquare[i] = new int[N];//this is the width

		
		for (i = 0; i < N; i++)
		{
			for (j = 0; j < N; j++)
				magsquare[i][j] = 0;
		}

		int k;
		int x = N / 2;
		int y = 0;
		
		magsquare[0][N / 2] = 1;

		for (k = 2; k <= N*N; k++)
		{
			int newx,newy;//store the new positions in these variable
			newx = x + 1;//move a coloum right
			newy = y - 1;//move a row up
			if (x + 1 >= N)
				newx = 0;
			if (y - 1 <= -1)
				newy = N - 1;
			x = newx;//change the x position with newx
			y = newy;//change the y position with newy
			if (magsquare[x][y] == 0)//the space is empty
				magsquare[x][y] = k;
			else
				magsquare[x][y+1] = k;//the space is occupied by a previous element so move below the last onw
		}
		cout << "this is the N*N magic square." << endl;
		for (i = 0; i < N; i++)
		{
			for (j = 0; j < N; j++)
				cout << setw(3) << magsquare[i][j];
			cout << endl;
		}
		answer1 = magsquare[0][0];
		answer2 = magsquare[N - 1][N - 1];
		for (i = 0; i < N; i++)//return the storage to the heap
		delete[] magsquare[i];
		delete[] magsquare;
	
    return 0;
}

