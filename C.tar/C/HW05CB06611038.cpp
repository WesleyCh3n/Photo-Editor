//================================================================
//  PROGRAMMER : LIEN WEI HSIANG 
//  DATE       : 2017-12-05
//  FILENAME   : HW05CB06611038.CPP 
//  DESCRIPTION   : Magic square
//================================================================


#include "stdafx.h"
#include <iostream>
#include <iomanip>
using namespace std;

int answer1; // Store the integer value of the cell at the top-left corner
int answer2;  // Store the integer value of the cell at the bottom-right corner

int main()
{
	int **p,N,i,j;
	cin >> N;
	p = new int *[N]; 
	for ( i = 0; i < N; i++)
	{
		p[i] = new int[N]; //create a Two-dimensional array
	}
	for (i = 0; i < N; i++)
	{
		for (j = 0; j < N; j++)
		{
			p[i][j] = 0;
	
		}
	}
	p[0][N / 2] = 1;
	int A=(N*N), B=(N*N+N/2);
	for (i = 2; i <= N*N; i++)
	{
		if (p[(A - 1) % N][(B + 1) % N] == 0)    //follow the rule
		{
			p[(A - 1) % N][(B + 1) % N] = i;
			A = A - 1;
			B = B + 1;
		}
		else
		{
			p[(A + 1) % N][B%N] = i;
			A = A + 1;
		}
	}
	for (i = 0; i < N; i++)
	{
		for (j = 0; j < N; j++)
		{
			cout <<setw(3)<< p[i][j] << " ";
		}
		cout << endl;
	}
	answer1 = p[0][0];
	answer2 = p[N - 1][N - 1];
	for ( i = 0; i < N; i++)
	{
		delete[] p[i];
	}
	delete[] p;
	cout << "the integer value of the cell at the top-left corner is " << answer1 << endl;
	cout << "the integer value of the cell at the bottom-right corner is " << answer2 << endl;
    return 0;
}

