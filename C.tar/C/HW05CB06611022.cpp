// HW05CB06611022.cpp : Defines the entry point for the console application.
//================================================================================================================================================
//  PROGRAMMER  : Nico Hokita
//  DATE        : 2017-12-09
//  FILENAME    : HW05BB06611022.cpp 
//  DESCRIPTION : This is a computer program that constructs and displays a magic square for any given odd number N
//================================================================================================================================================



#include "stdafx.h"
#include <iostream>
#include <iomanip>
using namespace std;

int answer1, answer2; 

int main() {
	int S=0;
	int row, col;

	while(S%2!=1){ //keep inputing until the side is odd
		cout << "Input the number of side square side (Odd Number): ";
		cin >> S;
	}

	int** arr = new int* [S]; //declare the row
	for (int n = 0; n < S; n++)
	{
		arr[n] = new int[S]; //declare the column
	}

	for (int i = 0; i < S; i++) { //fill empty array by 0
		for (int j = 0; j < S; j++) {
			arr[i][j] = 0;
		}
	}
	
	for (int num = 1; num <= (S*S); num++) { //loop stop when all cell filled
		
		if (num == 1) { //1 place in first row in the middle}
			row = 0;
			col = (S / 2);
			arr[row][col] = num; 
			continue;
		}
		
		//STEP1: PREDICT NEXT MOVE AND MOVE
		if (row - 1 < 0) { //first check: if there are no row at top of the number
			row = (S - 1); // move from first to last row
		}
		else { //else go up
			row--;
		}

		if (col + 1 == S) { //second check: if there are no col at the right of the number move from last col to first col
			col = 0; //move from last col to first col
		}
		else {
			col++; //else go right
		}

		//STEP2: CHECK RATHER THE CELL ARE FILLED OR NOT

		if (arr[row][col] != 0) { //in case cell has been filled
			if (row == (S - 1)) { //if row at last line
				row = 0; // move back 1 step
			}
			else { //else go down
				row++; //move back 1 step
			}

			if (col == 0) { //if col at first
				col = (S - 1); //move back
			}
			else {
				col--; //else go left
			}
			row++;
			arr[row][col] = num;
		}
		else { //cell hasn't be filled
			arr[row][col] = num;
		}
	}
	
	for (int k = 0; k < S; k++) { //display
		for (int l = 0; l < S; l++) {
			cout << setw(4)<< arr[k][l];
		}
		cout << endl;
	}
	answer1 = arr[0][0];
	answer2 = arr[S - 1][S - 1];
	delete[] arr;

	cout << answer1;
	cout << answer2;
	
	//system("PAUSE");
	return 0;
}
