//  PROGRAMMER :   CHOU,TING-HSUN
//  DATE                   : 2017-12-05
//  FILENAME         : HW05CB06611031.CPP 
//  DESCRIPTION   : This is a program to display a magic square
#include <iostream>
#include <iomanip> 
using namespace std;

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner


void move_fill(int filled_num,int row,int col,int N);//declaire

int magic_square[1000][1000]={};//set to 1000
void print_square(int N){//print
	for (int i = 0; i < N; ++i)
	{
		for (int j = 0; j < N; ++j)
		{
			cout <<setw(3)<< magic_square[i][j] ;
		}
		cout << endl;
	}
}

int rowT=0,colT=0;//put global

int main()
{
	int N;
	cout << "give me the N" <<endl;
	cin >> N;
	//put the first element 1
	colT=N/2;
	magic_square[rowT][colT]=1;
	for (int i = 1; i < N*N; ++i){
		move_fill(i+1,rowT-1,colT+1,N);
	}

	print_square(N);
	answer1=magic_square[0][0];
	answer2=magic_square[N-1][N-1];
	return 0;
}



//using recursion
void move_fill(int filled_num,int row,int col,int N){
	if (row<0){
		move_fill(filled_num,N-1,col,N);
	}
	else if (col==N){
		move_fill(filled_num,row,0,N);
	}
	else if (magic_square[row][col]!=0||(row+1==0&&col-1==N-1)){//at top-right corner or already had element
		magic_square[rowT+1][colT]=filled_num;
		rowT=rowT+1;//update
	}
	else{
		magic_square[row][col]=filled_num;
		rowT=row;//update
		colT=col;
	}
	return;
}
