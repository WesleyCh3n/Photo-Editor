//================================================================
//  PROGRAMMER    : ZHANG,MING-XIANG
//  DATE                       : 2017-12-05
//  FILENAME              : HW05CB06611036
//  DESCRIPTION       : Write a program that constructs and displays a magic square for any given odd number N.A magic square is a square of numbers with N rows and N columns, in which each integer value from 1 to (N*N) appears exactly once, 
//                                     and the sum of each column, each row, and each diagonal is the same value.
//================================================================

#include "stdafx.h"
#include <iostream>
using namespace std;

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main()
{
    int size; //int square size
	int** square; //using dynamic array to let people input size
	cout << "Please give odd number N then the magic square is a square of numbers with N rows and N columns: ";
	cin >> size; //cin square size
	if (size % 2 == 1 && size > 0) //generate square[size][]
		square = new int*[size];
	else //if input even then program exit
		exit(1);
	for (int i = 0; i < size; i++) //generate square[size][size]
		*(square + i) = new int[size];


	for (int i = 0; i < size; i++)       //initialize
		for (int j = 0; j < size; j++)
			square[i][j] = 0;


	square[0][size / 2] = 1; //first number
	for (int a = 2, i = 0, j = (size / 2), check1, check2; a <= (size*size); a++) //a is number to insert, i is row, j is column, check1 is to check if it changes to last row, check is to check if it changes to first colume
	{
		i--; //row-1
		j++; //column+1
		check1 = 0; //initialize every loop
		check2 = 0; //initialize every loop

		if (i < 0) {          //row<0 then row=size-1 and let check1=1 to let back program judge
			i = i + size;
			check1 = 1;
		}
		if (j >= size) {  //colunm>=size then column=0 and let check2=1 to let back program judge
			j = j - size;
			check2 = 1;
		}

		if (square[i][j] == 0) {     //if square [i][j]=0 then set a
			square[i][j] = a;
			continue;
		}
		else  //if square [i][j] != 0
			if (i == 0 && j == (size - 1)) {   // if in right-up corner
				square[1][size - 1] = a;
				i = 1;
				continue;
			}
			else if (check1 == 1 && check2 == 1) { //judge if it changes row or column or not and set a below original square [i][j] then change i and j
				square[i - size + 2][j + size - 1] = a;
				i = i - size + 2;
				j = j + size - 1;
				continue;
			}
			else if (check1 == 0 && check2 == 1) { //judge if it changes row or column or not and set a below original square [i][j] then change i and j
				square[i + 2][j + size - 1] = a;
				i = i + 2;
				j = j + size - 1;
				continue;
			}
			else if (check1 == 1 && check2 == 0) { //judge if it changes row or column or not and set a below original square [i][j] then change i and j
				square[i - size + 2][j - 1] = a;
				i = i - size + 2;
				j = j - 1;
				continue;
			}
			else if (check1 == 0 && check2 == 0) { //judge if it changes row or column or not and set a below original square [i][j] then change i and j
				square[i + 2][j - 1] = a;
				i = i + 2;
				j = j - 1;
				continue;
			}

	}

	for (int i = 0; i < size; i++) //cout square [i][j]
	{
		for (int j = 0; j < size; j++)
			cout << square[i][j];
		cout << endl;
	}

	answer1 = square[0][0];  // Store the integer value of the cell at the top-left corner
	answer2 = square[size - 1][size - 1];  // Store the integer value of the cell at the bottom-right corner

	delete[] square; //delete memory leak

	return 0;
}