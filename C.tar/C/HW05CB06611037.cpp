//======================================================================================================
//  PROGRAMMER : Chang Hsin Yang
//  DATE       : 2017-12-05
//  FILENAME   : HW05CB06611037.CPP 
//  DESCRIPTION: This is a program to constructs and displays a magic square for any given odd number N
//======================================================================================================


#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
int answer1; // Store the integer value of the cell at the top-left corner 
int answer2; // Store the integer value of the cell at the bottom-right corner

int main()
{
	int i, j;
	int a;
	int x, y, z;
	int N;
	cout << "Please input the number N :";
	cin >> N;//Let user to input the number N with a view to create a N*N array
	cout << endl;
	if (N % 2 == 0)//N must be a odd number
	{
		cout << "Invalid input";
		return 0;
	}
	int **magicsquare = new int*[N];//Create a two dimentional dynamic N*N array
	for (a = 0; a < N; a++)
		magicsquare[a] = new int[N];//Create a two dimentional dynamic N*N array
	for (i = 0; i < N; i++)
		for (j = 0; j < N; j++)
			magicsquare[i][j] = 0;//To intialize every element of magicsquare 0
	y = 0;
	z = ceil(N / 2);
	magicsquare[y][z] = 1;//1 would be the middle element of the first row of magicsquare
	cout << "The graph of the magicsquare is :" << endl;
	for (x = 2; x <= N*N; x++)
	{
		if (y != 0 && z != N-1)//The situation that magicsquare[y][z] is not at first row and not at last column
		{
			if (magicsquare[y - 1][z + 1] != 0)//If the number move to a position that is already filled or out of the upper-right corner. Then place the next number, x+1, immediately below x
			{
				y = y + 1;
				magicsquare[y][z] = x;
			}
			else//Fill x move up one row and to the right one column
			{
				y = y - 1;
				z = z + 1;
				magicsquare[y][z] = x;
			}
		}
		else if (y == 0 && z!= N-1)//The situation that magicsquare[y][z] is at first row and not at last column
		{
			if (magicsquare[N - 1][z + 1] != 0)//If the number move to a position that is already filled or out of the upper-right corner. Then place the next number, x+1, immediately below x
			{
				y = y + 1;
				magicsquare[y][z] = x;
			}
			else//If move off the top (row = -1) in any column,then move to the bottom row and place the next number, x+1, in the bottom row of that column.
			{
				y = N - 1;
				z = z + 1;
				magicsquare[y][z] = x;
			}
		}
		else if (y != 0 && z == N-1)//The situation that magicsquare[y][z] is not at first row and at last column
		{
			if (magicsquare[y - 1][0] != 0)//If the number move to a position that is already filled or out of the upper-right corner. Then place the next number, x+1, immediately below x
			{
				y = y + 1;
				magicsquare[y][z] = x;
			}
			else//If move off the right end(column = N) of a row,then place the next number, x + 1, in the first column of that row.
			{
				y = y - 1;
				z = 0;
				magicsquare[y][z] = x;
			}
		}
		else if (y == 0 && z == N-1)//The situation that magicsquare[y][z] is at first row and at last column
		{
			if (magicsquare[N - 1][0] != 0)//If the number move to a position that is already filled or out of the upper-right corner. Then place the next number, x+1, immediately below x
			{
				y = y + 1;
				magicsquare[y][z] = x;
			}
			else//Fill x at the last row and the first column
			{
				y = N - 1;
				z = 0;
				magicsquare[y][z] = x;
			}
		}
	}
	
	for (i = 0; i < N; i++)
	{
		for (j = 0; j < N; j++)
			cout << setw(4) << magicsquare[i][j];//Output the magic square that the question require
		cout << endl;
	}
	answer1 = magicsquare[0][0];//Answer1 is the integer value of the cell at the top-left corner
	answer2 = magicsquare[N - 1][N - 1];//Answer2 is the integer value of the cell at the bottom-right corner
	cout << "The integer value of the cell at the top-left corner is " << answer1 << endl;
	cout << "The integer value of the cell at the bottom-right corner is " << answer2 << endl;
	for (a = 0; a < N; a++)
		delete[]magicsquare[a];//Return the storge to the heap
	delete[]magicsquare;//Return the storge to the heap
    return 0;
}

