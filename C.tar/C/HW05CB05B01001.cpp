
//================================================================
//  PROGRAMMER : Ru-Xiu Hsiao
//  DATE       : 2017-12-06
//  FILENAME   : HW05CB05B01001.CPP
//  DESCRIPTION: Write a program that constructs and displays a magic square for any given odd number N.
//================================================================

#include <iostream>
//#include"stdafx.h"
#include<iomanip>
using namespace std;

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main() {
    int** array;//create a dynamic two dimesional array
    int rownum,colnum,totalnum;//store the row numer,column number and total number in the array
    
    int rownow=0,colnow=0;//initialize the initial condition
    //ask for a user input
    cout << "Please input a value which represents row number(column number) for a N x N array.";
    cin >> rownum;
    if(rownum==0){
        cout <<"Invalid input"<<endl;
        return 0;
    }
    colnum=rownum;//equal row number and column number
    totalnum=rownum*colnum;//calculate the total number in the array
    cout << "create an array of size " << rownum << "x" << colnum << endl;//declare what you do
    
    //build up array
    array = new int*[rownum];
    for (int i = 0; i < rownum; i++) {
        array[i] = new int[colnum];
    }
    //setup array initial state
    for(int i=0;i<rownum;i++){
        for(int j=0;j<colnum;j++){
            array[i][j]=0;
        }
    }
    
    //calculate the value in the array
    array[0][(colnum-1)/2]=1;
    rownow=0;
    colnow=(colnum-1)/2;
    for(int i=1; i < totalnum; i++){
        int num=i+1;
        //set condition for the next number
        //store the previous value of rownow, colnow
        int r,c;
        r=rownow;
        c=colnow;
        //general condition
        rownow--;
        colnow++;
        //if move off the top of the array
        if(rownow==-1){
            rownow=rownum-1;
        }
        //if move off the right of the array
        if(colnow>(colnum-1)){
            colnow=0;
        }
    
        //if the position already occupied
        if(array[rownow][colnow]!=0){
            rownow=r+1;
            if(rownow>rownum-1){
                rownow=0;
            }
            colnow=c;
        }
        //store the number into right podition
        array[rownow][colnow]=num;
    }
    
    //output the array
    cout <<"The table looks like below."<<endl;
    for(int i=0; i<rownum;i++){
        cout <<"___";
    }
    cout<<endl;
    
    for(int i=0; i <rownum;i++){
        for(int j=0;j <colnum;j++){
            cout <<setw(3)<< array[i][j];
        }
        cout << endl;
    }
    
    //asign and output the answer
    answer1=array[0][0];
    answer2=array[rownum-1][colnum-1];
    cout <<"The integer value of the cell at the top-left corner is "<<answer1<<endl;
    cout <<"The integer value of the cell at the bottom-right corner is "<<answer2<<endl;
   
    delete[] array;//release the memory
    return 0;
}
