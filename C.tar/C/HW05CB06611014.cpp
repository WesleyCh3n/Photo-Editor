//================================================================
//  PROGRAMMER            : Tsai Yu Tsung
//  DATE                   : 2017-12-05
//  FILENAME         : HW05CB06611014.CPP 
//  DESCRIPTION   : This is a program to make a magic square.
//================================================================


#include "stdafx.h"
#include <iostream>
#include <iomanip>
using namespace std;

int answer1;// Store the integer value of the cell at the top-left corner
int answer2;// Store the integer value of the cell at the bottom-right corner

int main()
{
	int n;//the side long
	cout << "input an odd number:";
	cin >> n;
	cout << endl;
	int **N = new int *[n];//ask the space
	for (int i = 0; i < n; i++)//instruct an array
	{
		N[i] = new int[n];
	}
	for (int j = 0; j < n; j++)//set all value in initial array to 0
	{
		for (int k = 0; k < n; k++)
		{
			N[j][k] = 0;
		}
	}
	int a = 0;
	int b = n / 2;
	N[a][b] = 1;//input 1 in the half of first line
	for (int z = 2; z < n*n; z++)//start to input the number
	{
		if (z%n == 1)//when it goes aturn,start at the below one
		{
			a = a + 1;
			N[a][b] = z;
		}

		else if (a == 0)//when it is at the edge of upside,jump to the downside
		{
			a = n - 1;
			b = b + 1;
			N[a][b] = z;
		}

		else if (b == (n - 1))//when it is at the edge of rightside,jump to the leftside
		{
			a = a - 1;
			b = 0;
			N[a][b] = z;
		}
		else//else just go right and go up
		{
			a = a - 1;
			b = b + 1;
			N[a][b] = z;
		}
	}
	for (int c = 0; c < n; c++)//output the result
	{
		for (int d = 0; d < n; d++)
		{
			cout << setw(5) << N[c][d];
		}
		cout << endl;
	}
	answer1 = N[0][0];//let answer1 store the value
	answer2 = N[n - 1][n - 1];//let answer2 store the value
	for (int x = 0; x < n; x++)//return the space
	{
		delete[] N[x];
	}
	delete[] N;//return the space
	return 0;
}

