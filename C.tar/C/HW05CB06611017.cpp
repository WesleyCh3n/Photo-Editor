//================================================================
//  PROGRAMMER  : Tom Tang
//  DATE        : 2017-12-7
//  FILENAME    : HW05CB06611017.CPP 
//  DESCRIPTION : This is a program to shows a magic square in which length N is input by user
//================================================================

#include "stdafx.h"
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int answer1; // Store the integer value of the cell at the top-left corner 
int answer2; // Store the integer value of the cell at the bottom-right corner


int main()
{
	int N;
	int **square;

	cout << " input the length of the magic square ";
	cin >> N; //let the user determine the length of the magic square

		int i, j;
		square = new int*[N]; // set a dynamic two-dimensional array
		for (i = 0; i < N; i++)
			square[i] = new int[N];

		for (i = 0; i < N; i++) // insert the value 0 in all cell 
			for (j = 0; j < N; j++)
				square[i][j] = 0;
		i = 0;
		j = N / 2;
		square[0][j] = 1; // insert the value 1 in the middle of the first row
		for (int x = 2; x <= pow(N, 2); x++) {
			if (i - 1 >= 0 && N > j + 1) {
				if (square[i - 1][j + 1] == 0) {
					square[i - 1][j + 1] = x;
					i = i - 1;
					j = j + 1;
				}
				else if (square[i - 1][j + 1] != 0) {
					square[i + 1][j] = x;
					i = i + 1;
				}
			}


			else if (i - 1 < 0 && N > j + 1) {
				if (square[N - 1][j + 1] == 0) {
					square[N - 1][j + 1] = x;
					i = N - 1;
					j = j + 1;
				}

				else if (square[N - 1][j + 1] != 0) {
					square[i + 1][j] = x;
					i = i + 1;
				}
			}

			else if (i - 1 >= 0 && j + 1 > N - 1) {
				if (square[i - 1][0] == 0) {
					square[i - 1][0] = x;
					i = i - 1;
					j = 0;
				}

				else if (square[i - 1][0] != 0) {
					square[i + 1][j] = x;
					i = i + 1;
				}
			}

			else if (i - 1 < 0 && j + 1 > N - 1) {
				if (square[N - 1][0] == 0) {
					square[N - 1][0] = x;
					i = N - 1;
					j = 0;
				}

				else if (square[N - 1][0] != 0) {
					square[i + 1][j] = x;
					i = i + 1;
				}
			}
		}

		cout << endl;
		for (i = 0; i < N; i++) {
			for (j = 0; j < N; j++) {
				cout << setw(3) << square[i][j]; // cout the array
			}		cout << endl;
		}

		answer1 = square[0][0];
		answer2 = square[N - 1][N - 1];
		cout << " the integer value of the cell at the top - left corner is " << answer1 << endl;
		cout << " the integer value of the cell at the bottom-right corner " << answer2;

		for (i = 0; i < N; i++)
			delete[] square[i];
		delete[] square; // delete the new array

	//system("pause");
	return 0;
}
