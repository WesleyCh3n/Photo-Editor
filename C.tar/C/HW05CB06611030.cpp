//PROGRAMMER:Yu Ying LEE                
//DATE:2017-12-06           
//FILENAME: HW05CB06611030.CPP          
//DESCRIPTION: Write a program that constructs and displays a magic square for any given odd number N

#include "stdafx.h"
#include <iostream>
#include <iomanip>
using namespace std;




int answer1; // Store the integer value of the cell at the top-left corner
int answer2; // Store the integer value of the cell at the bottom-right corner
int **A;
void magic_square(int **A,int);

int main()
{  
	int N, i, j;
	cout << "Please input the size(N x N) of magic square: " << endl;
	cout << "(Hint: N must be odd number)" << endl;
	cin >> N;
	A = new int*[N];
	for (i = 0;i <= N - 1;i++)
	{
		A[i] = new int[N];
	}
	for (i = 0;i <= N - 1;i++)
	{
		for (j = 0;j <= N - 1;j++)
		{
			A[i][j] = 0;
		}
	}
	magic_square(A, N);
	cout << endl << "The " << N << " x " << N << " magic square is :" << endl;
	for (i = 0;i <= N - 1;i++)
	{
		for (j = 0;j <= N - 1;j++)
		{
			cout << setw(5) << A[i][j] << " ";
			if (j == N - 1) cout << endl;
		}
	}
	answer1 = A[0][0];
	answer2 = A[N - 1][N - 1];
	delete[] A;
    return 0;
}


void magic_square(int **A, int N)
{
	int i, j=0, k=(N/2), m1=0, m2=0;
	A[0][k] = 1;
	for (i=2;i<=N*N;i++)
	{
		while (A[j][k] != 0)
		{
			j = j - 1;
			k = k + 1;
			if (j < 0)
			{
				m1 = N;
				j = j + m1;
			}
			else if (k > N-1)
			{
				m2 = N;
				k = k - m2;
			}
			if (A[j][k] == 0)
			{
				m1 = 0;
				m2 = 0;
				break;
			}
			else
			{
				j = j + 2 - m1;
				k = k - 1 + m2;
			}
			m1 = 0;
			m2 = 0;
		}
		A[j][k] = i;
	}

}


