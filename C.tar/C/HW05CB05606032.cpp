#include<iostream>
#include<cmath>
#include<stdlib.h>
using namespace std;
int  answer1;
int  answer2;
int main ()
{
    int N;


    cin>>N;
    int MS[N][N]={};
    int i=0;
    int j=N/2;
    for (int k=1;k<=N*N;k++)
    {
        MS[i][j]=k;
        if ((i==0)&&(j==N-1))
        {
            i=1;
            j=N-1;
          continue;
        }
        i-=1;
        if(i==-1) i=N-1;
        j+=1;
        if(j==N) j=0;
        if ((MS[i][j]!=0))
        {
            if ((i!=N-1)&&(j!=0) )
              {
                  i+=2;
                  j-=1;
                  continue;
              }
            if ((i=N-1)&&(j!=0) )
              {
                  i=1;
                  j-=1;
                   continue;
              }
              if ((i!=N-1)&&(j=0) )
              {
                  i+=2;
                  j=N-1;
                   continue;
              }
               if ((i=N-1)&&(j=0) )
              {
                  i=1;
                  j=N-1;
                   continue;
              }

        }

    }
    answer1=MS[0][0];
    answer2=MS[N-1][N-1];
    for (int p=0;p<N;p++)
    {
         for (int q=0;q<N;q++)
         {
             cout<<MS[p][q]<<' ';
         }
         cout<<endl;
    }
}

