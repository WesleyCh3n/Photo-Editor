//  PROGRAMMER : LIN YAN CHENG
//  DATE       : 2017-12-5
//  FILENAME   : HW05CB06611002.CPP 
//  DESCRIPTION: This is a program to  constructs and displays a magic square for any given odd number N.

#include "stdafx.h"
#include "iostream"
using namespace std;
int answer1; //Store the integer value of the cell at the top - left corner
int answer2; //Store the integer value of the cell at the bottom-right corner
int main()
{
	int arrray;
	int **pointerrr;
	cout << "Give me a odd number:";
	cin >> arrray;
	if (arrray % 2 == 1 && arrray > 0) //generate pointerrr[arrray][]
	{
		pointerrr = new int*[arrray];
	}
	else
	{
		cout << "OH BABY ! YOU ENTERED A WRONG NUMBER" << endl;
		exit(1);
	}
	int i = 0;
	while (i < arrray)
	{
		*(pointerrr + i) = new int[arrray];
		i++;
	}
	while (i<arrray)
	{
		int j = 0;
		while (j<arrray)
		{
			pointerrr[i][j] = 0;
			j++;
		}
		i++;
	}
	pointerrr[0][arrray / 2] = 1;
	int k = 2;
	int j = (arrray / 2);
	while (k <= arrray * arrray )
	{
		i--;
		j++;
		int looopa = 0;
		int looopb = 0;
		if (i<0)
		{
			i = i + arrray;
			looopa = 1;
		}
		if (j >= arrray)
		{
			j = j - arrray;
			looopb = 1;
		}
		if (pointerrr[i][j] == 0)
		{
			pointerrr[i][j] = k;
			continue;
		}
		else
		{
			if (i == 0 && j == arrray - 1)
			{
				pointerrr[1][arrray - 1] = k;
				i = 1;
				continue;
			}
			else if (looopa == 1 && looopb == 1)
			{
				pointerrr[i - arrray + 2][j + arrray - 1] = k;
				i = i - arrray + 2;
				j = j + arrray - 1;
				continue;
			}
			else if (looopa == 0 && looopb == 1)
			{
				pointerrr[i + 2][j + arrray - 1] = k;
				i = i + 2;
				j = j + arrray - 1;
				continue;
			}
			else if (looopa == 1 && looopb == 0)
			{
				pointerrr[i - arrray + 2][j - 1] = k;
				i = i - arrray + 2;
				j = j - 1;
				continue;
			}
			else if (looopa == 0 && looopb == 0)
			{
				pointerrr[i + 2][j - 1] = k;
				i = i + 2;
				j = j - 1;
				continue;
			}
		}
		i = 0;
		while (i < arrray) //cout pointerrr[i][j]
		{
			j = 0;
			while (j < arrray)
			{
				cout << pointerrr[i][j];
				j++;
			}
			cout << endl;


			i++;
		}
		
		




		k++;
	}






	answer1 = pointerrr[0][0]; // Store the integer value of the cell at the top-left corner
	answer2 = pointerrr[arrray - 1][arrray - 1]; // Store the integer value of the cell at the bottom-right corner
	delete[] pointerrr;






	
	return 0;
}

