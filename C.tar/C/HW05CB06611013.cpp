//================================================================
//  PROGRAMMER : HSIAO CHIA HONG
//  DATE       : 2017-12-06
//  FILENAME   : HW05CB06611013.CPP 
//  DESCRIPTION: This is a program to  constructs and displays a magic square for any given odd number N
//================================================================


#include "stdafx.h"
#include "iostream"
#include "iomanip"
using namespace std;

int answer1;  // Store the integer value of the cell at the top-left corner
int answer2; // Store the integer value of the cell at the bottom-right corner

void a(bool matrix[][100], int matrix2[][100], int k); // arrange the order and store the number

int main()
{
	int n;
	cin >> n;
	bool matrix[100][100] = { false };//judge the position whether has a number already
	int matrix2[100][100]; // store the number
	matrix[0][n / 2] = true;
	matrix2[0][n / 2] = 1;
	a(matrix, matrix2, n);
	for (int i = 0; i < n; i++) // print the number
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(2) << matrix2[i][j] << "  ";
		}
		cout << endl;
	}
	answer1 = matrix2[0][0];
	answer2 = matrix2[n - 1][n - 1];
    return 0;
}

void a(bool matrix[][100], int matrix2[][100], int k)
{
	int m = 0;
	int n = k / 2;
	for (int i = 2; i < k*k+1; i++)
	{
		int a = m;
		int b = n;
		if (m==0)
		{
			m = k - 1;
		}
		else
		{
			m--;
		}
		if (n==k-1)
		{
			n = 0;
		}
		else
		{
			n++;
		}
		if (matrix[m][n]==false)
		{
			matrix[m][n] = true;
			matrix2[m][n] = i;
		}
		else
		{
			a++;
			m = a;
			n = b;
			matrix[m][n] = true;
			matrix2[m][n] = i;
		}
	}
}