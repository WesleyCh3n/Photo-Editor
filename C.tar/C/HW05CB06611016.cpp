//================================================================
//  PROGRAMMER :Chen Chia Yu
//  DATE       : 2017-12-6
//  FILENAME   : HW05CB06611016.CPP 
//  DESCRIPTION   : This is a program to produce a magic square with N rows and N columns
//================================================================
#include "stdafx.h"
#include<iostream>
#include<iomanip>
#include<new>
using namespace std;
int answer1;// Store the integer value of the cell at the top-left corner
int answer2;// Store the integer value of the cell at the bottom-right corner
int main()
{
	int i, j, k, n;
	int **temp ;//declare two-dimensional dynamic arrary
	cin >> k;//input what rows you want
	temp = new int*[k];//produce one-dimensional pointer arrary
	for (i = 0; i < k; i++)//each pointer arrary produce integer array
		temp[i] = new int[k];
	for (i = 0; i < k; i++)//first make each element in this arrary become zero
	{
		for (j = 0; j < k; j++)
			temp[i][j] = 0;
	}
	i = 0;
	j = k / 2;
	temp[i][j] = 1;//first assign 1 into the element at the first row and the middle column
	for (n = 2; temp[i][j] != k*k; n++)
	{
		int a = i, b = j;//store the original index of last element 
		i = i - 1;//transfer to next element's index
		j = j + 1;
		if (i < 0)//however,if the index is out of bound, you need to transfer it back to area and in correct index
			i = i + k;
		if (j > k - 1)
			j = j - k;
		if (temp[i][j] != 0)//if the next element isn't equal to zero, it represent there is filled in a number previously; if previos situation is right, then you need to fill the number down the last element
		{
			i = a + 1;
			j = b;
			temp[i][j] = n;
		}
		else
			temp[i][j] = n;
	}
	for (i = 0; i < k; i++)// output the magic square
	{
		for (j = 0; j < k; j++)
			cout << setw(5) << temp[i][j];
		cout << endl;
	}
	answer1 = temp[0][0];
	answer2 = temp[k - 1][k - 1];
	cout<<"the cell at the top-left corner is " << answer1 << endl;
	cout <<"the cell at the bottom-right corner is "<< answer2 << endl;
	for (i = 0; i < k; i++)//return the storage to the heap
		delete[] temp[i];
	delete[] temp;
	return 0;
}

