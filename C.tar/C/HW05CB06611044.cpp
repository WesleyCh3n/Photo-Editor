//================================================================
//  PROGRAMMER : AMY CHAN
//  DATE: 2017-12-07
//  FILENAME: HW05B06611044.CPP 
//  DESCRIPTION: This is a program to do magic square
//================================================================
#include<iostream>
using namespace std;
int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner
int main()
{
	int n;
	cin >> n;
	int A[n][n];
	int pY = n - 1, pX = n / 2;
	for (int i = 0; i<n; i++)
	{
		//find out next position
		for (int j = 0; j<n; j++)
		{
			//when encounter the position that is not a blank
			if (j == 0)
			{
				if (pY + 1>n - 1) //boarder
					pY = pY - n + 1;
				else
					pY = pY + 1;
			}
			else
			{
				if (pY - 1 >= 0)
					pY = pY - 1;
				else   //boarder
					pY = pY + n - 1;
				if (pX + 1 <= n - 1)
					pX = pX + 1;
				else   //boarder
					pX = pX - n + 1;
			}
			A[pY][pX] = i*n + j + 1;
		}
	}
	//print the result
	for (int i = 0; i<n; i++)
	{
		for (int j = 0; j<n; j++)
			cout << A[i][j] << " ";
		cout << endl;
	}
	answer1 = A[0][0];
	answer2 = A[n - 1][n - 1];
	return 0;
}