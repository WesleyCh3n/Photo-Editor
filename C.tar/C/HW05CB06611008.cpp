//================================================================
//  PROGRAMMER : YI-HAU LAI
//  DATE       : 2017-12-08
//  FILENAME   : HW05CB06611008.CPP
//  DESCRIPTION: This is a program to find Magic Square
//================================================================

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int answer1;     // Store the integer value of the cell at the top-left corner
int answer2;     // Store the integer value of the cell at the bottom-right corner

int main() {
    int N;//size of square
    
    //get the N
    cout<<"Please give an odd number N "<<endl;
    cin>>N;

    int squ[N][N];//claim the array of square
    
    //preset the square to zero
    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
            squ[i][j]=0;
        }
    }
    
    
    int x=2;//the value to give the blanks
    int i=0-1,j=N/2+1; //initial position
    squ[0][N/2]=1;//insert the value 1 in the middle of the first row
    
    
    //do the algorithm
    do {
        if (i<0 && j>=N) {
            i=i+2;j=j-1;
            squ[i][j]=x;
        }else if(i<0 && j<N){
            i=N-1;j=j;
            squ[i][j]=x;

        }else if(i>=0&&j>=N){
            i=i;j=0;
            squ[i][j]=x;
        }else if (i>=0 && j<N){
            if (squ[i][j]!=0) {
                 i=i+2;j=j-1;
            }
            squ[i][j]=x;
        }
        i--;j++;x++;
        
    } while (x!=pow(N, 2)+1);
    
    //print the result
    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
            cout<<setw(3)<<squ[i][j];
        }
        cout<<endl;
    }
    
    //for webcat
    answer1=squ[0][0];
    answer2=squ[N-1][N-1];
    
    return 0;
}


