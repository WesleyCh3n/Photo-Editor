// PROGRAMMER : Meng-Lei,Lin
// DATE : 2017-12-07
// FILENAME : HW05CB06611001.CPP
// DESCRIPTION : This is a program to compute and display the magic square

#include <iostream>
using namespace std;

int answer1,answer2;

void generate(int n);

int main()
{
    int n;
    
    cout<<"Please enter an odd number you wish to display: ";
    cin>>n;
    while(n%2==0)//avoid even numbers
    {
        cout<<endl<<"Please enter an odd number";
        cin>>n;
    }
    
    generate(n);//use funtion
    
    
    
    
    return 0;
}

void generate(int n)
{
    int square[n][n];
    int i=n/2,j=n-1;
    int num;
    memset(square,0,sizeof(square));//set all slots at 0
    for(num=1;num<=n*n;)
    {
        if (i==-1 && j==n)//consider all 3 conditions and fill in slots respectively
        {
            j = n-2;
            i = 0;
        }
        else
        {
            if(j==n)
                j=0;
            if(i<0)
                i=n-1;
        }
        if (square[i][j])
        {
            j -= 2;
            i++;
            continue;
        }
        else
            square[i][j] = num++;
        j++; i--;
        
    }
    
    
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            cout<<square[i][j]<<" ";
        }
        cout<<endl;
    }
    answer1=square[0][0];
    answer2=square[n-1][n-1];
}
