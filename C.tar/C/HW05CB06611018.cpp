// PROGRAMMER: Shao Zhan Mei
// DATE: 2017-12-6
// FILENAME: HW05CB06611018
// DESCRIPTION: This is a program displaying a magic 

#include "stdafx.h" // Load precompiled header file
#include <iostream> // Load header file, introduce outputs & inputs
#include <iomanip> // Load header file, introduce setw()

using namespace std; // std is a namespace in standard library

int answer1; // Store the integer value of the cell at the top-left corner
int answer2; // Store the integer value of the cell at the bottom-right corner

int main()
{
	int N, k = 2; // N is the width of the square, k is the value placed in the square
	cout << "Enter the width (Columns & Rows) of the square:" << endl;
	cin >> N;
	int** square; // Declare a dynamic two-dimensional array

	if (N % 2 == 1) // The width of the magic square has to be an odd number
		square = new int*[N]; // The number of the rows
	else
		exit(1);

	for (int i = 0; i < N; i++)
		for (int j = 0; j < N; j++)
			square[i] = new int[N]; // Declare the columns of the array

	for (int i = 0; i < N; i++)
		for (int j = 0; j < N; j++)
			square[i][j] = 0; // Make all the elements 0

	square[0][N / 2] = 1; // Insert 1 in the middle of the first row

	for (int i = -1, j = N / 2 + 1; k <= N * N; i--, j++, k++) { // i stands for the row of the square, j the column
		                                                         // The initial of i, j is moved up and right once from square[0][N/2]
		if (i < 0)
			i = i + N;
		if (j > N - 1)
			j = j - N; // Make the position inside the square


		if (square[i][j] == 0)
			square[i][j] = k;

		else {
			if (i == 0 && j == N - 1) {
				i = 1;
				square[i][j] = k;
			} // When moved to the upper-right corner
			else if (i + 1 >= N - 1 && j - 1 >= 0) {
				i = i + 1 - N + 1;
				j = j - 1;
				square[i][j] = k;
			}
			else if (i + 1 < N - 1 && j - 1 < 0) {
				i = i + 1 + 1;
				j = j - 1 + N;
				square[i][j] = k;
			}
			else if (i + 1 >= N - 1 && j - 1 < 0) {
				i = i + 1 - N + 1;
				j = j + N - 1;
				square[i][j] = k;
			}
			else if (i + 1 < N - 1 && j - 1 >= 0) {
				i = i + 1 + 1;
				j = j - 1;
				square[i][j] = k;
			}
		}
	}

	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++)
			cout << setw(N * N / 10 + 1) << square[i][j];
		cout << endl;
	}

	answer1 = square[0][0];
	answer2 = square[N - 1][N - 1];

	delete[]square; // Delete the dynamic array

	return 0;
}